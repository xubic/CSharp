﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homeWork07
{
    public partial class Form1 : Form
    {
        private Graphics graphics; 
        int n = 10;
        int leng = 100;
        Pen pen = Pens.Blue;
        double th1 = 30 * Math.PI / 180;
        double th2 = 20 * Math.PI / 180;
        double per1 = 0.6;
        double per2 = 0.7;
        public Form1()
        {
            InitializeComponent();
        }


        private void btnDraw_Click(object sender, EventArgs e)
        {
            if(graphics == null)
            {
                graphics = drawPanel.CreateGraphics();
            }
            graphics.Clear(this.BackColor);

            n = trackBar1.Value;
            leng = trackBar2.Value;
            per1 = (double)trackBar3.Value / 20;
            per2 = (double)trackBar4.Value / 20;
            th1 = trackBar5.Value * Math.PI / 180;
            th2 = trackBar6.Value * Math.PI / 180;

            switch (comboBox1.Text)
            {
                case "Pen.Red":
                    pen = Pens.Red; break;
                case "Pen.Blue":
                    pen = Pens.Blue; break;
                case "Pen.Yellow":
                    pen = Pens.Yellow; break;
                case "Pen.Green":
                    pen = Pens.Green; break;
            }

            drawCayleyTree(n, 200, 310, leng, -Math.PI / 2);

        }
        void drawCayleyTree(int n, double x0,double y0,double leng,double th)
        {
            if (n == 0) return;

            double x1 = x0 + leng * Math.Cos(th);
            double y1 = y0 + leng * Math.Sin(th);

            drawLine(x0, y0, x1, y1);

            drawCayleyTree(n - 1, x1, y1, per1 * leng, th + th1);
            drawCayleyTree(n - 1, x1, y1, per2 * leng, th - th2);
        }

        void drawLine(double x0,double y0,double x1,double y1)
        {
            graphics.DrawLine(pen, (int)x0, (int)y0, (int)x1, (int)y1);
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label1.Text = "递归深度：" + trackBar1.Value;
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            label3.Text = "主干长度：" + trackBar2.Value;
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            label4.Text = "右分支长度比：" + (double)trackBar3.Value / 20;
        }

        private void trackBar4_Scroll(object sender, EventArgs e)
        {
            label5.Text = "左分支长度比：" + (double)trackBar4.Value / 20;
        }

        private void trackBar5_Scroll(object sender, EventArgs e)
        {
            label6.Text = "右分支角度：" + trackBar5.Value;
        }

        private void trackBar6_Scroll(object sender, EventArgs e)
        {
            label7.Text = "左分支角度：" + trackBar6.Value;
        }
    }
}
