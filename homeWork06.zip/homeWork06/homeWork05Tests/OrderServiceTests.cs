﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using homeWork05;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace homeWork05.Tests
{
    [TestClass()]
    public class OrderServiceTests
    {
        OrderService orderService = new OrderService();
        List<Order> result;
        Order order01;
        Order order02;
        Order order03;
        OrderItem item;

        [TestInitialize]
        public void Initial()
        {
            order01 = new Order("1", 200, "001");
            order01.customer.Name = "x";
            order02 = new Order("2", 100, "002");
            order02.customer.Name = "b";
            order03 = new Order("3", 300, "003");
            order03.customer.Name = "c";
            item = new OrderItem("手机",100);
            order03.AddOrderItem(item);
            //OrderService orderService = new OrderService();
            orderService.AddOrder(order01);
            orderService.AddOrder(order02);
            orderService.AddOrder(order03);
            result = new List<Order>() { order02, order01, order03 };
        }

        [TestCleanup]
        public void CleanUp()
        {
            order01 = null;
            order01 = null;
            order01 = null;
            orderService = null;
            result = null;
        }

        [TestMethod()]
        public void SortOrderTest()
        {
            orderService.SortOrder();
            CollectionAssert.AreEqual(orderService.orderList, result); 
        }

        [TestMethod()]
        public void AddOrderTest()
        {
            bool isExist = orderService.AddOrder(order01);//成功添加订单时返回true
            Assert.IsTrue(isExist);
        }

        [TestMethod()]
        public void SearchOrderTest01()//测试只靠订单号查询
        {
            List<Order> list = orderService.SearchOrder("001", null, null);

            Assert.IsTrue(list[0].Equals(order01));
        }

        [TestMethod()]
        public void SearchOrderTest02()//测试靠订单号和客户名查询
        {
            List<Order> list = orderService.SearchOrder("002", "b", null);

            Assert.IsTrue(list[0].Equals(order02));
        }

        [TestMethod()]
        public void SearchOrderTest03()//测试靠订单号和客户名和货物查询
        {
            List<Order> list = orderService.SearchOrder("003", "c", "手机");

            Assert.IsTrue(list[0].Equals(order03));
        }

        [TestMethod()]
        public void SearchOrderTest04()//测试查询不成功的情况
        {
            List<Order> list = orderService.SearchOrder(null, null, null);

            Assert.IsNull(list);
        }

        [TestMethod()]
        public void DeleteOrderTest()
        {

            bool isDelete = orderService.DeleteOrder(order01.OrderNumber);
            Assert.IsTrue(isDelete);
        }

        [TestMethod()]
        public void ModifyOrderTest()
        {
            orderService.ModifyOrder("003", "xbc", "配件");
            List<Order> list = orderService.SearchOrder("003", "xbc", "配件");
            Assert.IsNotNull(list);
        }

        [TestMethod()]
        public void ExportTest()//检测序列化是否成功
        {
            List<Order> list = orderService.orderList;
            string path = "s.xml";
            orderService.Export(path);
            orderService.Import(path);
            bool isImport = true;
            for (int i = 0; i < list.Count; i++)
            {
                isImport = (list[i].Equals(orderService.orderList[i])) && true;
            }
            Assert.IsTrue(isImport);
        }

        [TestMethod()]
        public void ImportTest()//检测反序列化是否成功
        {
            List<Order> list = orderService.orderList;
            string path = "s.xml";
            orderService.Export(path);
            orderService.Import(path);
            bool isImport = true;
            for(int i = 0; i < list.Count; i++)
            {
               isImport= (list[i].Equals(orderService.orderList[i])) && true;
            }
            Assert.IsTrue(isImport);
        }
    }
}