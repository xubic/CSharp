﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace homeWork05
{
    public class OrderService
    {
        public List<Order> orderList = new List<Order>();

        public OrderService() { }   //无参构造函数
        public void SortOrder()//根据订单价格给订单列表排序
        {
            orderList.Sort((order01, order02) => order01.Price - order02.Price);
            foreach (Order order in orderList)
            {
                Console.WriteLine(order.Name);
            }
        }
        public int GetPrice()   //获取订单的总价格
        {
            int price = 0;
            foreach (Order orders in orderList)
            {
                price += orders.Price;
            }
            return price;
        }

        public bool AddOrder(Order order)//增加订单
        {
            bool isExist = false;  //检验要加入的订单是否已经存在
            foreach (Order order1 in orderList)
            {
                isExist = isExist || order1.Equals(order);
            }
            if (!isExist)
            {
                orderList.Add(order);
            }
            else
            {
                Console.WriteLine("该订单已经存在！");
            }
            return isExist;
        }
        //public List<Order> SearchOrderByNumber(string number)//根据订单号查询订单
        //{
        //    var searchOrder = from order in orderList
        //                      where order.Number.Equals(number)
        //                      select order;
        //    List<Order> list = new List<Order>();
        //    foreach(var s in searchOrder)
        //    {
        //        list.Add(s);
        //    }
        //    return list;
        //}
        //public List<Order> SearchOrderByCustomerName(string customerName)//根据用户名查询订单
        //{
        //    var searchOrder = from order in orderList
        //                      where order.customer.Name.Equals(customerName)
        //                      select order;
        //    List<Order> list = new List<Order>();
        //    foreach (var s in searchOrder)
        //    {
        //        list.Add(s);
        //    }
        //    return list;
        //}
        //public List<Order> SearchOrderByCargoName(string cargoName)//根据订单号查询订单
        //{
        //    var searchOrder = from order in orderList
        //                      where order.Name.Equals(cargoName)
        //                      select order;
        //    List<Order> list = new List<Order>();
        //    foreach (var s in searchOrder)
        //    {
        //        list.Add(s);
        //    }
        //    return list;
        //}
        public List<Order> SearchOrder(string number, string customerName, string cargoName)//查询订单
        {
            var searchByNumber = orderList.Where(s => s.OrderNumber == number);//通过订单号查询
            // var searchBycustomer = orderList.Where(s => s.customer.Name.Equals(customerName));//通过用户名查询
               // var searchBycargo = orderList.Where(s => s.Name.Equals(cargoName));//通过商品名称查询

            var searchByNumAndCustomer = searchByNumber.Where(s => s.customer.Name == customerName);//通过订单号和客户名查询
            var searchByAll = searchByNumAndCustomer.Where(s => { //通过订单号，客户名，商品名
                foreach(OrderItem item in s.orderItem)
                {
                     if (item.Name == cargoName) return true;
                }
                return false;
            });

            List<Order> list = new List<Order>();
            Console.WriteLine("符合要求的订单有：");
            if (number != null && customerName == null && cargoName == null)
            {
                foreach (var s in searchByNumber)
                {
                    list.Add(s);
                    Console.WriteLine(s.Name);
                }
                return list;
            }
            if (number != null && customerName != null && cargoName == null)
            {
                foreach (var s in searchByNumAndCustomer)
                {
                    list.Add(s);
                    Console.WriteLine(s.Name);
                }
                return list;
            }
            if (number != null && customerName != null && cargoName != null)
            {
                foreach (var s in searchByAll)
                {
                    list.Add(s);
                    Console.WriteLine(s.Name);
                }
                return list;
            }
            else
            {
                Console.WriteLine("查询输入参数出错！");
                return null;
            }


        }

        public bool DeleteOrder(string number)//根据订单号删除
        {
            var searchOrder = from order in orderList
                              where order.Number.Equals(number)
                              select order;
            if(searchOrder == null)
            {
                return false;
            }
            else
            {
                foreach (var s in searchOrder)
                {
                    orderList.Remove(s);
                }
                return true;
            }

        }

        public void ModifyOrder(string number, string customerName, string cargoName)//通过订单号查询，修改客户名和商品名
        {
            List<Order> list = new List<Order>();
            list = this.SearchOrder(number, null, null);
            if (list == null)
            {
                Console.WriteLine("所要修改的订单号不存在！");
            }
            else
            {
                Order order = new Order();
                foreach (Order order1 in list)
                {
                    order.customer.Name = customerName;
                    order.Name = cargoName;
                    Console.WriteLine("修改订单成功！");
                    Console.WriteLine("修改之后的信息为：");
                    Console.WriteLine(order.ToString());
                }
            }
        }

        public void Export(String path)//将所有的订单序列化为XML文件
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Order>));
            using (FileStream fs = new FileStream(path, FileMode.Create))
            {
                xmlSerializer.Serialize(fs, orderList);
            }
            Console.WriteLine("\nSerialized as XML:");
            Console.WriteLine(File.ReadAllText(path));
        }

        public void Import(String path)//从XML文件中载入订单
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Order>));
            using (FileStream fout = new FileStream(path, FileMode.Open))
            {
                orderList = (List<Order>)xmlSerializer.Deserialize(fout);
                Console.WriteLine("\nDeserialized:");
                foreach(Order order in orderList)
                {
                    Console.WriteLine(order);
                }
            }
        }

    }
}
