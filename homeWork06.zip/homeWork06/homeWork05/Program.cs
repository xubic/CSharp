﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homeWork05
{
    class Program
    {
        static void Main(string[] args)
        {
            //创建一个客户
            Customer customer01 = new Customer();
            customer01.Name = "徐必成";
            customer01.Address = "武汉大学";
            customer01.Tel = "12345";

            //创建订单明细对象
            OrderItem orderItem01 = new OrderItem("手机", 1000);
            OrderItem orderItem02 = new OrderItem("手机壳", 1000);
            OrderItem orderItem03 = new OrderItem("手机膜", 1000);

            //创建订单对象
            Order order01 = new Order();
            order01.AddOrderItem(orderItem01);
            order01.AddOrderItem(orderItem02);
            order01.Name = "手机和配件";
            order01.OrderNumber = "0001";
            order01.customer = customer01;
            order01.Destination = customer01.Address;
            order01.Price = order01.GetPrice();
            Console.WriteLine(order01.ToString());

            Order order02 = new Order();
            order02.AddOrderItem(orderItem03);
            order02.Name = "手机膜";
            order02.OrderNumber = "0002";
            order02.customer = customer01;
            order02.Destination = customer01.Address;
            order02.Price = order02.GetPrice();
            Console.WriteLine(order02.ToString());


            //增加订单
            OrderService orderService = new OrderService();
            orderService.AddOrder(order01);
            orderService.AddOrder(order02);
            orderService.SortOrder();

            //序列化与反序列化
            string path = "s.xml";
            orderService.Export(path);
            orderService.Import(path);


            //查询订单
            orderService.SearchOrder("0001", null, null);
            orderService.SearchOrder("0005", null, null);

            //修改订单
            orderService.ModifyOrder("0001", "xbc", "shouji");

        }
    }
}
