﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homeWork05
{
    public class OrderItem
    {
        public string Name { set; get; }//货物名称
        public int Price { set; get; }//货物价格

        public OrderItem() { }
        public OrderItem(string name, int price)
        {
            Name = name;
            Price = price;
        }
        public override bool Equals(object obj)
        {
            OrderItem item = obj as OrderItem;
            return item != null && Name == item.Name && Price == item.Price;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()//订单明细信息
        {
            return "货物名称：" + this.Name + "  货物价格：" + this.Price;
        }

    }
}
