﻿using System;

namespace hello
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            double a = 0;
            double b = 0;
        //提醒用户输入
            Console.WriteLine("This is a calculator in c#: ");
            
            try
            {
                Console.WriteLine("Please input a numble,and then press enter");
                a = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Please input another numble,and then press enter: ");
                 b = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Please Choose an option from：+,-,*,/");
                switch (Console.ReadLine())
                {
                    case "+":
                        Console.WriteLine("The result is {0}", a + b);
                        break;
                    case "-":
                        Console.WriteLine("The result is {0}", a - b);
                        break;
                    case "*":
                        Console.WriteLine("The result is {0}", a * b);
                        break;
                    case "/":
                            Console.WriteLine("The result is {0}", a / b);
                        break;
                    default:
                        Console.WriteLine("error!");
                        break;
                }
            }
            catch(FormatException) {
                Console.WriteLine("the format is wrong!");
            }catch (OverflowException)
            {
                Console.WriteLine("the number is overflow!");
            }catch (Exception)
            {
                Console.WriteLine("this expression is wrong!");
            }  
             
        }
    }
}
