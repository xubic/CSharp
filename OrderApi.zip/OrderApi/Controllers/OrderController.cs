﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrderApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrderApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderController : ControllerBase
    {
        public readonly OrderContext orderDb;
        public OrderController(OrderContext context)
        {
            this.orderDb = context;
        }

        //通过客户姓名获取客户信息
        [HttpGet("customer/{name}")]
        public ActionResult<List<Customer>> GetCustomer(string name)
        {
            var query = orderDb.Customers.Where(c => c.Name == name);
            if (query == null)
            {
                return NotFound();
            }

            return query.ToList();
        }

        //获取订单详情
        [HttpGet]
        public ActionResult<List<Order>> GetAllOrder()
        {
            var allOrders = orderDb.Orders/*.Include(o => o.Items.Select(i => i.GoodsItem)).Include("Customer")*/;
            if(allOrders == null)
            {
                return NotFound();
            }
            return allOrders.ToList();
        }

        //根据订单号来查询订单情况
        [HttpGet("{id}")]
        public ActionResult<List<Order>> GetOrders(string id)
        {
            var allOrders = orderDb.Orders/*.Include(o => o.Items.Select(i => i.GoodsItem)).Include("Customer")*/;

            var query = allOrders.Where(o => o.Id == id);

            if(query == null)
            {
                return NotFound();
            }
            return query.ToList();
        }

        //添加订单
        [HttpPost]
        public ActionResult<Order> PostOrders(Order o)
        {
            try
            {
                orderDb.Orders.Add(o);
                orderDb.SaveChanges();
            }
            catch(Exception e)
            {
                return BadRequest(e.InnerException.Message);
            }

            return o;
        }

        //修改订单
        [HttpPut("{id}")]
        public ActionResult<Order> PutOrder(string id, Order order)
        {
            if (id != order.Id)
            {
                return BadRequest("Id cannot be modified!");
            }
            try
            {
                orderDb.Entry(order).State = EntityState.Modified;
                orderDb.SaveChanges();
            }
            catch (Exception e)
            {
                string error = e.Message;
                if (e.InnerException != null) error = e.InnerException.Message;
                return BadRequest(error);
            }
            return NoContent();
        }

        //删除订单
        [HttpDelete("{id}")]
        public ActionResult DeleteOrder(string id)
        {
            try
            {
                var todo = orderDb.Orders.FirstOrDefault(t => t.Id == id);
                if (todo != null)
                {
                    orderDb.Remove(todo);
                    orderDb.SaveChanges();
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.InnerException.Message);
            }
            return NoContent();
        }

    }
}
