﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clock
{
    class Program
    {
        static void Main(string[] args)
        {
            EventResponse alarm01 = new EventResponse();
            alarm01.alarm.StartClock();
        }


    public delegate void ClockHander(object sender, AlarmTime args);

    public class AlarmTime //作为委托参数的格式
    {
        public int Hour { set; get; }
        public int Minute { set; get; }
        public int Second { set; get; }

        public AlarmTime(int h, int m, int s)
        {
            Hour = h;
            Minute = m;
            Second = s;
        }
    }

     public class Clock
     {
        public event ClockHander Tick;//创建一个事件
        public event ClockHander Alarm;//创建响铃事件

        private AlarmTime targetTime = new AlarmTime(0, 0, 10); //目标时间   

        private  readonly AlarmTime currentTime = new AlarmTime(0, 0, 0);//开始时间

        public void SetTrtgetTime(int h, int m, int s)  //修改目标时间
            {
                this.targetTime = new AlarmTime(h, m, s);
            }
        public void StartClock()//启动闹钟
        {
            while (true)
            {
                currentTime.Second++;
                Tick(this, currentTime);
                if(currentTime.Hour == targetTime.Hour && currentTime.Hour == targetTime.Minute &&
                    currentTime.Second == targetTime.Second)
                {
                    Alarm(this, targetTime);
                }
                System.Threading.Thread.Sleep(1000);
            }
        }
     }

        public class EventResponse  //订阅事件的类
        {
            public Clock alarm = new Clock();
            public EventResponse()
            {
                alarm.Tick += new ClockHander(AlarmRun);
                alarm.Alarm += new ClockHander(AlarmCall);
            }
            public void AlarmRun(object sender, AlarmTime args)
            {
                Console.WriteLine("滴答~ 滴答~");
            }
            public void AlarmCall(object sender, AlarmTime args)
            {
                Console.WriteLine("时间到了！");
            }
        }
    }
}
