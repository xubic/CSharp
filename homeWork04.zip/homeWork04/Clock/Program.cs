﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clock
{
    class Program
    {
        static void Main(string[] args)
        {
            eventResponse alarm01 = new eventResponse();
            alarm01.alarm.StartClock();
        }


    public delegate void ClockHander(object sender, ClockEventArgs args);

    public class ClockEventArgs //作为委托参数的格式
    {
        public int Hour { set; get; }
        public int Minute { set; get; }
        public int Second { set; get; }

        public ClockEventArgs(int h, int m, int s)
        {
            Hour = h;
            Minute = m;
            Second = s;
        }
    }

     public class Clock
     {
        public event ClockHander Tick;//创建一个事件
        public event ClockHander Alarm;//创建响铃事件

        private ClockEventArgs targetTime= new ClockEventArgs(0, 0, 10);//目标时间

        private ClockEventArgs startTime = new ClockEventArgs(0, 0, 0);//开始时间

        public void StartClock()//启动闹钟
        {
            while (true)
            {
                startTime.Second++;
                Tick(this, startTime);
                if(startTime.Hour == targetTime.Hour && startTime.Hour == targetTime.Minute && 
                    startTime.Second == targetTime.Second)
                {
                    Alarm(this, targetTime);
                }
                System.Threading.Thread.Sleep(1000);
            }
        }
     }

        public class eventResponse  //订阅事件的类
        {
            public Clock alarm = new Clock();
            public eventResponse()
            {
                alarm.Tick += new ClockHander(alarmRun);
                alarm.Alarm += new ClockHander(alarmCall);
            }
            public void alarmRun(object sender, ClockEventArgs args)
            {
                Console.WriteLine("滴答~ 滴答~");
            }
            public void alarmCall(object sender, ClockEventArgs args)
            {
                Console.WriteLine("时间到了！");
            }
        }
    }
}
