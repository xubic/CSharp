﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderApp {

  class MainClass {
    public static void Main() {
      try {
        //OrderItem apple = new OrderItem(1, "apple",10.0, 80);
        //OrderItem egg = new OrderItem(2, "eggs",1.2, 200);
        //OrderItem milk = new OrderItem(3, "milk",50, 10);

        //Order order1 = new Order(1, "Customer1", new List<OrderItem> { apple, egg, milk });
        //Order order2 = new Order(2, "Customer2", new List<OrderItem> { egg, milk });
        //Order order3 = new Order(3, "Customer2", new List<OrderItem> { apple, milk });

        //OrderService os = new OrderService();
        //os.AddOrder(order1);
        //os.AddOrder(order2);
        //os.AddOrder(order3);
        //os.Export(@"./orders.xml");

        //Console.WriteLine("GetAllOrders");
        //List<Order> orders = os.Orders;
        //orders.ForEach(o => Console.WriteLine(o));
        //Console.WriteLine("");

        //os.Sort((o1, o2) => o1.TotalPrice.CompareTo(o2.TotalPrice));
        //Console.WriteLine("GetAllOrders After sort");
        //orders = os.Orders;
        //orders.ForEach(o => Console.WriteLine(o));
        //Console.WriteLine("");

        //Console.WriteLine("GetOrdersByCustomerName:'Customer2'");
        //orders = os.QueryOrdersByCustomerName("Customer2");
        //orders.ForEach(o => Console.WriteLine(o));
        //Console.WriteLine("");

        //Console.WriteLine("GetOrdersByGoodsName:'apple'");
        //orders = os.QueryOrdersByGoodsName("apple");
        //orders.ForEach(o => Console.WriteLine(o));
        //Console.WriteLine("");

        //Console.WriteLine("Remove order(id=2) and qurey all");
        //os.RemoveOrder(2);
        //orders.ForEach(o => Console.WriteLine(o));
        //Console.WriteLine("");

        //Console.WriteLine("Import from ./orders.xml");
        //OrderService os2 = new OrderService();
        //os2.Import("./orders.xml");
        //os2.Orders.ForEach(order => Console.WriteLine(order));

      }catch (Exception e) {
        Console.WriteLine(e.Message);
        Console.WriteLine(e.StackTrace);
      }
            //向数据库中添加订单,添加顾客
            using (var context = new OrderContext())
            {
                var customer = new Customer { ID = "0001", Name = "xubicheng"};
                context.Customers.Add(customer);

                context.SaveChanges();

                var customer1 = context.Customers.SingleOrDefault(o => o.ID == "0001");
                if (customer1 != null)
                {
                    Console.WriteLine("订单查询结果为：");
                    Console.WriteLine($"customer1.Name = {customer1.Name}");
                }
            }
            ////向数据库中添加订单,添加货物
            //using (var context = new OrderContext())
            //{
            //    var order = new Order { OrderId = 5 ,CustomerID = "001"};
            //    order.Items = new List<OrderItem>
            //    {
            //        new OrderItem{Index = 1, Quantity = 1,GoodsItemID = "001"},
            //        new OrderItem{Index = 2, Quantity = 2,GoodsItemID = "001"}
            //    };
            //    context.Orders.Add(order);
            //    context.SaveChanges();
            //}

            ////向数据库中添加货物
            //using (var context = new OrderContext())
            //{
            //    context.Goods.Add(new Goods { ID = "07", Name = "iphone", Price = 1000 });
            //    context.Goods.Add(new Goods { ID = "08", Name = "ipad", Price = 100 });

            //    context.SaveChanges();
            //}

            ////根据id查找order
            //using (var context = new OrderContext())
            //{
            //    var orders = context.Orders.SingleOrDefault(o => o.OrderId == 5);
            //    if (orders != null)
            //    {
            //        Console.WriteLine("订单查询结果为：");
            //        Console.WriteLine($"orders.OrderId = {orders.OrderId}");
            //    }
            //}

            ////根据id修改order
            //using (var context = new OrderContext())
            //{
            //    var orders = context.Orders.SingleOrDefault(o => o.OrderId == 5);
            //    if (orders != null)
            //    {
            //        orders.CustomerID = "aaaaaa";
            //        context.SaveChanges();
            //        Console.WriteLine("修改之后的结果为：");
            //        Console.WriteLine($"orders.CustomerID = {orders.CustomerID}");
            //        Console.WriteLine(orders);
            //    }
            //}

            ////根据id删除货物
            //using (var context = new OrderContext())
            //{
            //    //var orders = context.Orders.SingleOrDefault(o => o.OrderId == 5);
            //    var goods = context.Goods.SingleOrDefault(g => g.ID == "07");
            //    if (goods != null)
            //    {
            //        context.Goods.Remove(goods);
            //        context.SaveChanges();
            //        var m = context.Goods.SingleOrDefault(g => g.ID == "07");
            //        if(goods == null)
            //        {
            //            Console.WriteLine("删除成功！");
            //        }
            //    }
            //}

        }
    }
}
