﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("输入一个正整数：");
            string str = Console.ReadLine();
            int num=0;
            try
            {
                 num = int.Parse(str);
            }
            catch (Exception)
            {
                Console.WriteLine("输入出错！");
            }

            if (num <= 1)
            {
                Console.WriteLine("请重新输入！");
            }

            bool isPrime;   //判断是否为质数

            for (int i = 2; i <= num; i++)
            {
                if (num % i == 0)
                {
                    isPrime = true;//假设i是质数
                    for (int j = 2; j < i; j++)
                    {
                        if (i % j == 0)
                        {
                            isPrime = false;
                        }
                    }
                    if (isPrime)
                    {
                        Console.WriteLine(i);
                    }
                }
            }
         }
        
    }
}
