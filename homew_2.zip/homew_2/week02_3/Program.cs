﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week02_3
{
    class Program
    {
        static void Main(string[] args)
        {
            bool[] isPrimenumber = new bool[101];
            for (int i = 2; i < isPrimenumber.Length; i++)
                isPrimenumber[i] = true;

            for(int i = 2; i < 10; i++)
            {
                if (!isPrimenumber[i])
                    continue;
                else
                {
                    for(int j = i+i; j <= 100; j = j + i)
                    {
                        isPrimenumber[j] = false;
                    }
                }
            }
            Console.WriteLine("2~100内的质数有：");
            for(int i = 2; i < isPrimenumber.Length; i++)
            {
                if (isPrimenumber[i])
                    Console.WriteLine(i);
            }
        }
    }
}
