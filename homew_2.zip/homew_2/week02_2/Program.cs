﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week02_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arry = new int[] { 1, 2, 3, 4, 5 };
            int sum = GetSum(arry);
            int max = GetMax(arry);
            int min = GetMin(arry);
            
            Console.WriteLine($"数组的最大值为{max},最小值为{min},元素总和为{sum},平均值为{sum / arry.Length}");
        }
        public static int GetMax(int[] arry)
        {
            int max = arry[0];
            for (int i = 0; i < arry.Length; i++)
            {
                if (arry[i] > max)
                    max = arry[i];
            }
              return max;
        }//获取数组最大值
        public static int GetMin(int[] arry)
        {
            int min = arry[0];
            for (int i = 0; i < arry.Length; i++)
            {
                if (arry[i] < min)
                    min = arry[i];
            }
            return min;
        }//获取数组最小值
        public static int GetSum(int[] arry)
        {
            int sum = 0;
            for (int i = 0; i < arry.Length; i++)
                sum += arry[i];
            return sum;
        }//获取数组元素和
    }
}
