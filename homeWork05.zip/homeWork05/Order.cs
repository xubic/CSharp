﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homeWork05
{
    public class Order
    {
            public List<OrderItem> orderItem = new List<OrderItem>();//存储订单明细的列表

            public string Name { set; get; }//商品名称
            public string OrderNumber { set; get; }  //订单号
            public int Price { set; get; }//订单价格
            public string Destination { set; get; }//订单目的地
            public int Number { set; get; }//订单中货物数量

            public Customer customer = new Customer();

            public Order()  //构造函数
            {
                OrderNumber = "";
                Price = this.GetPrice();
                Number = this.GetNumber();
            }
            public int GetPrice()//获取订单总价格
            {
                int price = 0;
                foreach (OrderItem item in orderItem)
                {
                    price += item.Price;
                }
                return price;
            }
            public int GetNumber()//获取订单总数量
            {
                int n = 0;
                foreach (OrderItem item in orderItem)
                {
                    n++;
                }
                return n;
            }
            public void AddOrderItem(OrderItem item)//增加订单明细
            {
                orderItem.Add(item);
            }
            public override bool Equals(object obj) //判断订单是否重复
            {
                Order order = obj as Order;
                return order != null && OrderNumber == order.OrderNumber;
            }
            public override string ToString()//订单信息
            {
                return "订单号：" + this.OrderNumber + "    订单总价格：" + this.Price + "    订单目的地："
                    + this.Destination + "    收件人姓名：" + customer.Name + "    收件人电话号码：" + customer.Tel;
            }
            public override int GetHashCode()
            {
                return base.GetHashCode();
            }
    }
}
