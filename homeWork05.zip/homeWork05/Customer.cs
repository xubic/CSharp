﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homeWork05
{
    public class Customer   //客户
    {
        public string Name { set; get; }
        public string Address { set; get; }
        public string Tel { set; get; }

        //       public OrderService orderService = new OrderService();

        public override string ToString()//客户信息
        {
            return "客户名：" + this.Name + "   客户地址：" + this.Address + "   客户电话号码：" +
                this.Tel;
        }
    }
}
