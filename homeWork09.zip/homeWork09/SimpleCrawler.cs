﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using System.Net;

namespace homeWork09
{
    class SimpleCrawler
    {
        private Hashtable urls = new Hashtable();
        private int count = 0;

        private string currentUrl;
        public string BaseUrl = "";
        //public string current = "";
        public string StartURL;

        public Action<string> PageDownloaded;   //定义一个委托

        public void Start()
        {
            urls.Add(StartURL, false);//加入初始页面

            //找到起始网页的url
            string baseurl = @"((www.)[^/]*)";

            BaseUrl = new Regex(baseurl).Matches(StartURL)[0].Value;
            //BaseUrl:www.cnblogs.com

            //Console.WriteLine("BaseUrl:" + BaseUrl);

            Crawl();
        }

        private void Crawl()
        {
            Console.WriteLine("开始爬行了.... ");
            while (true)
            {
                string current = null;
                foreach (string url in urls.Keys)//寻找未爬过的url
                {
                    if ((bool)urls[url]) continue;   //如果已经爬过则跳过该网页
                    if (!url.Contains($"{BaseUrl}")) continue;  //只爬取起始网站上的网页
                    current = url;
                }

                if (current == null || count > 10)//网页数目限制为10个
                    break;
                Console.WriteLine("爬行" + current + "页面!");
                string html = DownLoad(current); 
                urls[current] = true;
                count++;
                currentUrl = current;
                Parse(html);        //解析当前页面得到的字符串
                Console.WriteLine("爬行结束");
            }
        }

        public string DownLoad(string url)
        {
            try
            {
                WebClient webClient = new WebClient();
                webClient.Encoding = Encoding.UTF8;
                string html = webClient.DownloadString(url);
                string fileName = count.ToString();
                File.WriteAllText(fileName, html, Encoding.UTF8);
                PageDownloaded(url);
                return html;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return "";
            }
        }

        private void Parse(string html)
        {
            string strRef = @"(href|HREF)[ ]*=[ ]*[""'][^""'#>]+[""']";
            MatchCollection matches = new Regex(strRef).Matches(html);

            foreach (Match match in matches)
            {
                strRef = match.Value.Substring(match.Value.IndexOf('=') + 1)//截取等号出现的位置到结束
                          .Trim('"', '\"', '#', '>');//删除首位的 ' " # >

                if (strRef.Length == 0) continue;

             //       strRef = AbsoluteUrl(strRef); //求绝对地址

                //获取以html或者htm结尾的网页
                if (!Regex.IsMatch(strRef, @".cnblogs.com/dstang2000/.+.(html|htm)+$")) continue;

                if (urls[strRef] == null) urls[strRef] = false;

            }
        }

        public string AbsoluteUrl(string relativeUrl)//获取绝对地址,传入相对地址strRef
        {
            string baseu = @"((http|https)://[^/]*)";
            baseu = new Regex(baseu).Matches(StartURL)[0].Value;

            if (relativeUrl.StartsWith("http"))
            {

            }
            if (relativeUrl.StartsWith("/"))   //相对地址以 / 开头,转换到根目录
            {
                relativeUrl += this.BaseUrl;
            }
            else if (relativeUrl.StartsWith("../")) //相对地址以 ../ 开头，转换到前一级目录
            {
                //找到前一级地址
                int index = relativeUrl.LastIndexOf("/");
                string url = relativeUrl.Remove(index);
                index = url.LastIndexOf("/");
                relativeUrl = url.Substring(0, index + 1);
            }
            else
            {
                relativeUrl += this.currentUrl;
            }

            //不知道为什么每个得到的绝对地址尾部后面都会有StartURL
            //所以我把得到的地址全部末尾删去startUrl
            int index1 = relativeUrl.LastIndexOf($"{StartURL}");
            if (!(index1 < 0))
            {
                relativeUrl = relativeUrl.Remove(index1);
            }

            Console.WriteLine("绝对地址：" + relativeUrl);
            return relativeUrl;
        }
    }
}
