﻿namespace homeWork08
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.OKBtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PriceTxt = new System.Windows.Forms.TextBox();
            this.QuantityTxt = new System.Windows.Forms.TextBox();
            this.GoodsNameTxt = new System.Windows.Forms.TextBox();
            this.indexTxt = new System.Windows.Forms.TextBox();
            this.PriceLbl = new System.Windows.Forms.Label();
            this.QuantityLbl = new System.Windows.Forms.Label();
            this.customerTxt = new System.Windows.Forms.TextBox();
            this.orderIdTxt = new System.Windows.Forms.TextBox();
            this.GoodsNameLbl = new System.Windows.Forms.Label();
            this.indexLbl = new System.Windows.Forms.Label();
            this.CustomerLbl = new System.Windows.Forms.Label();
            this.orderIDLbl = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.OKBtn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 90);
            this.panel1.TabIndex = 0;
            // 
            // OKBtn
            // 
            this.OKBtn.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.OKBtn.Location = new System.Drawing.Point(275, 25);
            this.OKBtn.Name = "OKBtn";
            this.OKBtn.Size = new System.Drawing.Size(97, 31);
            this.OKBtn.TabIndex = 0;
            this.OKBtn.Text = "确定";
            this.OKBtn.UseVisualStyleBackColor = true;
            this.OKBtn.Click += new System.EventHandler(this.OKBtn_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.PriceTxt);
            this.panel2.Controls.Add(this.QuantityTxt);
            this.panel2.Controls.Add(this.GoodsNameTxt);
            this.panel2.Controls.Add(this.indexTxt);
            this.panel2.Controls.Add(this.PriceLbl);
            this.panel2.Controls.Add(this.QuantityLbl);
            this.panel2.Controls.Add(this.customerTxt);
            this.panel2.Controls.Add(this.orderIdTxt);
            this.panel2.Controls.Add(this.GoodsNameLbl);
            this.panel2.Controls.Add(this.indexLbl);
            this.panel2.Controls.Add(this.CustomerLbl);
            this.panel2.Controls.Add(this.orderIDLbl);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 90);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 360);
            this.panel2.TabIndex = 1;
            // 
            // PriceTxt
            // 
            this.PriceTxt.Location = new System.Drawing.Point(498, 172);
            this.PriceTxt.Name = "PriceTxt";
            this.PriceTxt.Size = new System.Drawing.Size(100, 25);
            this.PriceTxt.TabIndex = 11;
            // 
            // QuantityTxt
            // 
            this.QuantityTxt.Location = new System.Drawing.Point(346, 172);
            this.QuantityTxt.Name = "QuantityTxt";
            this.QuantityTxt.Size = new System.Drawing.Size(100, 25);
            this.QuantityTxt.TabIndex = 10;
            // 
            // GoodsNameTxt
            // 
            this.GoodsNameTxt.Location = new System.Drawing.Point(206, 172);
            this.GoodsNameTxt.Name = "GoodsNameTxt";
            this.GoodsNameTxt.Size = new System.Drawing.Size(100, 25);
            this.GoodsNameTxt.TabIndex = 9;
            // 
            // indexTxt
            // 
            this.indexTxt.Location = new System.Drawing.Point(69, 172);
            this.indexTxt.Name = "indexTxt";
            this.indexTxt.Size = new System.Drawing.Size(100, 25);
            this.indexTxt.TabIndex = 8;
            // 
            // PriceLbl
            // 
            this.PriceLbl.AutoSize = true;
            this.PriceLbl.Location = new System.Drawing.Point(521, 132);
            this.PriceLbl.Name = "PriceLbl";
            this.PriceLbl.Size = new System.Drawing.Size(47, 15);
            this.PriceLbl.TabIndex = 7;
            this.PriceLbl.Text = "Price";
            // 
            // QuantityLbl
            // 
            this.QuantityLbl.AutoSize = true;
            this.QuantityLbl.Location = new System.Drawing.Point(343, 131);
            this.QuantityLbl.Name = "QuantityLbl";
            this.QuantityLbl.Size = new System.Drawing.Size(71, 15);
            this.QuantityLbl.TabIndex = 6;
            this.QuantityLbl.Text = "Quantity";
            this.QuantityLbl.Click += new System.EventHandler(this.QuantityLbl_Click);
            // 
            // customerTxt
            // 
            this.customerTxt.Location = new System.Drawing.Point(206, 84);
            this.customerTxt.Name = "customerTxt";
            this.customerTxt.Size = new System.Drawing.Size(100, 25);
            this.customerTxt.TabIndex = 5;
            // 
            // orderIdTxt
            // 
            this.orderIdTxt.Location = new System.Drawing.Point(69, 84);
            this.orderIdTxt.Name = "orderIdTxt";
            this.orderIdTxt.Size = new System.Drawing.Size(100, 25);
            this.orderIdTxt.TabIndex = 4;
            // 
            // GoodsNameLbl
            // 
            this.GoodsNameLbl.AutoSize = true;
            this.GoodsNameLbl.Location = new System.Drawing.Point(214, 132);
            this.GoodsNameLbl.Name = "GoodsNameLbl";
            this.GoodsNameLbl.Size = new System.Drawing.Size(79, 15);
            this.GoodsNameLbl.TabIndex = 3;
            this.GoodsNameLbl.Text = "GoodsName";
            // 
            // indexLbl
            // 
            this.indexLbl.AutoSize = true;
            this.indexLbl.Location = new System.Drawing.Point(84, 132);
            this.indexLbl.Name = "indexLbl";
            this.indexLbl.Size = new System.Drawing.Size(47, 15);
            this.indexLbl.TabIndex = 2;
            this.indexLbl.Text = "index";
            // 
            // CustomerLbl
            // 
            this.CustomerLbl.AutoSize = true;
            this.CustomerLbl.Location = new System.Drawing.Point(222, 47);
            this.CustomerLbl.Name = "CustomerLbl";
            this.CustomerLbl.Size = new System.Drawing.Size(71, 15);
            this.CustomerLbl.TabIndex = 1;
            this.CustomerLbl.Text = "Customer";
            // 
            // orderIDLbl
            // 
            this.orderIDLbl.AutoSize = true;
            this.orderIDLbl.Location = new System.Drawing.Point(84, 47);
            this.orderIDLbl.Name = "orderIDLbl";
            this.orderIDLbl.Size = new System.Drawing.Size(63, 15);
            this.orderIDLbl.TabIndex = 0;
            this.orderIDLbl.Text = "orderID";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button OKBtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox PriceTxt;
        private System.Windows.Forms.TextBox QuantityTxt;
        private System.Windows.Forms.TextBox GoodsNameTxt;
        private System.Windows.Forms.TextBox indexTxt;
        private System.Windows.Forms.Label PriceLbl;
        private System.Windows.Forms.Label QuantityLbl;
        private System.Windows.Forms.TextBox customerTxt;
        private System.Windows.Forms.TextBox orderIdTxt;
        private System.Windows.Forms.Label GoodsNameLbl;
        private System.Windows.Forms.Label indexLbl;
        private System.Windows.Forms.Label CustomerLbl;
        private System.Windows.Forms.Label orderIDLbl;
    }
}