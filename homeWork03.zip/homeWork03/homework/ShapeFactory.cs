﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework
{
    class ShapeFactory
    {
        public IShape GetShape(String type)
        {
            type = type.ToUpper();
            Random rnd = new Random();
            double a = rnd.Next(1, 20);
            double b = rnd.Next(1, 20);
            double c = rnd.Next(1, 20);
            switch (type)
            {
                case "TRIANGLE":
                    Triangle triangle= new Triangle(a, b, c);
                    while (!triangle.IsLegal())
                    {
                        a = rnd.Next(1, 20);
                        b = rnd.Next(1, 20);
                        c = rnd.Next(1, 20);
                        triangle = new Triangle(a, b, c);
                    };
                    return triangle;
                case "RECTANGLE":
                    return new Rectangle(a, b);
                case "SQUARE":
                    return new Square(a);
                default:
                    return null;
            }
        }
    }
}
