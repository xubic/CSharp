﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework
{
    class Square : Rectangle
    {
        private double side;
        public double Side { set; get; }

        public Square(double side):base(side,side)
        {
            this.side = side;
        }
    }
}
