﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] str = new string[3] { "Rectangle", "Triangle", "Square" };
            Random rnd = new Random();
            ShapeFactory shapeFactory = new ShapeFactory();
            IShape shape;
            double allArea = 0;
            for (int i = 1; i <=10; i++)
            {
                int a = rnd.Next(0, 3);
                shape = shapeFactory.GetShape(str[a]);
                allArea += shape.GetArea();
            }
            Console.WriteLine($"面积总和为{allArea}");
        }
    }
}
