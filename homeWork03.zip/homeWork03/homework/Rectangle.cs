﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework
{
    class Rectangle:IShape  //矩形类
    {
        private double width;
        private double heigth;
        public double Width //属性
        {
            get => width;
            set => width=value;
        }
        public double Heigth { set; get; }

        public Rectangle(double width,double heigth)
        {
            this.width = width;
            this.heigth = heigth;
        }
        public double GetArea()
        {
            if (IsLegal())
            {
                return width * heigth;
            }
            else
            {
                Console.WriteLine("边长输入出错！");
                return -1;
            }
  
        }

        public bool IsLegal()
        {
            return (width > 0 && heigth > 0);
           // throw new NotImplementedException();
        }
    }
}
