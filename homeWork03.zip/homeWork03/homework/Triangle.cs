﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework
{
    class Triangle : IShape
    {
        private double a;
        private double b;
        private double c;

        public Triangle(double a,double b,double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }
        public double GetArea()
        {
            if (IsLegal())
            {
                double s = (a + b + c) / 2;
                return (Math.Sqrt(s * (s - a) * (s - b) * (s - c)));
            }
            else
            {
                Console.WriteLine("输入的三边长度不符合三角形规则！");
                return -1;
            }
        }

        public bool IsLegal()
        {
            bool one = (a > 0 && b > 0 && c > 0);
            bool two = (a + b > c && a + c > b && b + c > a);
            return (one && two);
        }
    }
}
