﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace homework
{
    interface IShape
    {
        double GetArea();//计算面积
        bool IsLegal();//判断形状是否合法
    }
}
